----------------------------------------------------
Jason Knight's Realistic Renegade Sounds 
---------------------------------------------------- 
Created By: Jason Knight 
---------------------------------------------------- 

--------------
Installation 
--------------
Extract the files into your C&C Renegade Data Folder. Default path would be as follows. 
c:/Westwood/Renegade/Data 

Once they are in this folder, you may start your game and start playing, and you will see that your weapon sounds are now, DRASTICALLY different. 

-------------- 
Discription 
-------------- 
Basically this is a modification for all of you Renegade players that want to make the game a little more enjoyable. And by more enjoyable I mean, louder gun shots, more explosive sounds. And all around a more realistic sound based environment. 

------------------
v1.6 (current)
------------------
Ion Cannon Beacon Beep is Different
Nuke Missle Beacon Beep Is Different.
Rail Gun Is Louder and has a better mix.
Flame Thrower sounds like fire now.
Tiberium Fletchet has a crisper sound.
New Chaingun Sound
New SNiper Rifle Sound
New Ramjet Sound.



--------
v1.55 
--------
Every sound is now Upgraded In SOund Quiality, Every SOund Is Now 48hz 16bit

----------------------------------------------------------------------------------------------
v1.5 (All SOunds From TNX's Tiberian Sun Renegade SOund Pack
v1.5 Upgrades Are Property Of TNX, JasonKnight Did Not Create THem, BUt Did Modify Them Some.
----------------------------------------------------------------------------------------------

Rocket Launcher Fire
Rifle Fire
Orca Start And Stop (TS)
Obolisk Of Light Charge And Fire (TS)
Nod Light Tank Fire
Med Tank Tire
Mammonth Tank Fire

(I Figured I WOuld Make It More Fun, Cabal And Eva Are Now The Voices)
"GDI Structure Destroyed" (BOTH)
"GDI Base Under Attack" (BOTH)
"GDI Barracks Destroyed" (BOTH)
"GDI Barracks Under Attack" (BOTH)
"GDI Power PLant Destroyed" (BOTH)
"GDI Power Plant Attack" (BOTH)
"GDI Tiberium Refinery Destroyed" (BOTH)
"GDI Tiberium Refinery Under Attack" (BOTH)
"GDI PRODUCTION FACILITY DESTROYED" (BOTH)
"NOD Structure Destroyed" (GDI) - "Critical Structure Lost" (NOD)
"NOD Base Under Attack" (BOTH)
"Hand Of NOD Destroyed" (BOTH)
"Hand Of NOD Under Attack" (BOTH)
"NOD Power PLant Destroyed" (BOTH)
"NOD Power Plant Attack" (BOTH)
"NOD Tiberium Refinery Destroyed" (BOTH)
"NOD Tiberium Refinery Under Attack" (BOTH)
"GDI PRODUCTION FACILITY DESTROYED" (BOTH)
"Unit Ready" (BOTH)
"Cluster Missle Approaching" (BOTH)
"Ion Cannon Approaching" (BOTH)
"Ion Cannon Ready" (BOTH)
"Cluster Missle Detected" (BOTH)
"Ion Cannon Deactivated" (BOTH)
"Cluster Missle DDeactivated" (BOTH)
"NOD Harvester Under Attack" (BOTH)
"GDI Harvester Under Attack" (BOTH)

-----
v1.4
-----
Redid Boink (Now An Actual Person Saying. "Ok, Ya Got Him")
New Chain Gun Reload
Pistol Reload 
Railgun Reload
Tiberium Pistol Automatic
Tiberium Pistol Automatic Reload
Tiberium Rifle Automatic
Tiberium Rifle Automatic Reload
Volt Rifle Sound Modified
Ion Becon Beep Changed (yet again)
Rifle Reload Made Shorter To Fit Animation A Little Better
Flame Thrower Reload
Chemical Sprayer Fire
4 New Explosions (Changed The 4 That Sounded Close To The C4)
2 New Vehical Explosions
Nuke Explosion + Lowerd By 75%
Ion Explosion + Lowerd By 75%
Timed C4 (Took Out Beeps) 
Remote C4 (Took Out "Bomb Has Been PLanted")

------
v1.3
------
Ion Beacon Beep Changed
Nuke Beacon Beep Changed
Nuke Explosion + Build Up Made 200% Louder
Ion Explosion + Build Up Made 200% Louder
Deadeye/BlackHand Sniper Rifle Reload
New Bullet Hit Body Sound (Hard To Hear, But Its There)
3 New Metal Ricochet Sounds (Hard To Hear, But Its There)

-------
v1.2 
-------
Chain Gun Reload 
RamJet Reload 
Portable Ion Cannon Reload 
Timed C4 (Now has a person say (Bomb Has Been Planted, then followed By Beeps, So You WIll Know If YOur Near It) 
Remote C4 (Sounds Like Its Heavyer Drop, Then Person Says, Bomb Has Been PLanted) 
Land Mine C4 (No More CHarging Up, Just A Plop) 

---------------------
v1.1 (Unreleased) 
---------------------
New Boink 
Rifle Reload 

----- 
v1.0 
----- 
Pistol (not silenced, Sounds Like A Desert Eagle) 
Soilder Rifle (louder) 
Shot Gun (12 Gauge Sound Now) 
Rocket Launcher (HOLY SH!T, thats loud) 
Officer Chain Gun (and the loop, lower pitched, sounds more deadly) 
Deadeye/BlackHand SNiper Rifle (sounds good to me, makes it sound more deadly) 
RamJet (sounds like a single shot from a AK47) 
Gernade Launcher (deaper sound like its lauching a larger gernade) 
Portable Ion Cannon (I think this turned out good, listen to it) 
Stealth Laser Gun (Funny Sounding Laser, Its 2 Laser Sounds Mixed Into 1) 
Chain Laser (Higher Pitched Of THe First One, Still Cool Sounding) 
Rail Gun (Just Funny, But Cool) 
Repair Laser (One Word - EGON - HalfLife poeple know wha im talking about) 
Volt Rifle (idk what to call it, but i like it) 

------------------- 
Future Versions 
------------------- 
GDI APC Weapon Fire 
Hummer Weapon Fire 
MLRS Weapon Fire 
Medium Tank Weapon Fire 
Mammoth Tank Weapon Fire 
Buggy Weapon Fire 
NOD APC Weapon Fire 
Mobile Artillery Weapon Fire 
Light Tank Weapon Fire 
Flame Tank Weapon Fire 
Stealth Tank Weapon Fire 
Shot Gun Reload 
Rocket Launcher Reload 
Gernade Launcher Reload 
Stealth Laser Gun Reload 
Volt Rifle Reload 

And what ever else I can think of. 

------------------------------
(c)2004 - Jason Knight
------------------------------