var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

var maxGlowPoints = 3;
var maxRadiusDivisions = 6;
var maxRadius = 16;

for(var currentRadiusDivision = 1; currentRadiusDivision < maxRadiusDivisions; ++currentRadiusDivision) {
	var currentRadius = maxRadius * currentRadiusDivision / maxRadiusDivisions;
	var currentAngleBase = Math.PI * 2 * currentRadiusDivision / maxRadiusDivisions / maxGlowPoints;
	for(var currentGlowPoint = 0; currentGlowPoint < maxGlowPoints; ++currentGlowPoint) {
		var currentAngle = currentAngleBase + Math.PI * 2 * currentGlowPoint / maxGlowPoints;
		outputStream.writeLine("	sprol0f 373 " + Math.round(currentRadius * Math.cos(currentAngle)) + " " + Math.round(currentRadius * Math.sin(currentAngle)));
	}
	outputStream.writeLine("	wait 2");
}

outputStream.Close();