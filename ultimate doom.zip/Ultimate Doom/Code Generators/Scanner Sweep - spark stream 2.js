var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

// Public variables
var maxRadius = 125;
var minRadius = 32;
var maxPoints = 7;
var baseAngleTurnAmount = 2 * Math.PI / 64;
var angleTurnAmountInterval = 0;

var streamOutBlockArray = new Array();

// Program entry point
for(var currentIteration = 0; currentIteration < 3; ++currentIteration) {
	var currentAngleTurnAmount = baseAngleTurnAmount;
	var currentBaseAngle = 2 * Math.PI * -currentIteration / 32;
	for(var currentPointNumber = 0; currentPointNumber < maxPoints; ++currentPointNumber) {
		var currentRadius = (maxRadius - minRadius) * currentPointNumber / (maxPoints - 1) + minRadius;
		
		for(var currentDirection = 1; currentDirection < 32; currentDirection += 4) {
			var currentAngle = currentBaseAngle + 2 * Math.PI * currentDirection / 32;
			var currentX = Math.round(currentRadius * Math.cos(currentAngle));
			var currentY = Math.round(currentRadius * Math.sin(currentAngle));
			
			outputStream.WriteLine("	imgol08 559 " + currentX + " " + currentY);
		}
		outputStream.WriteLine("	wait 2");
		
		currentBaseAngle += currentAngleTurnAmount;
		currentAngleTurnAmount += angleTurnAmountInterval;
	}
//	outputStream.WriteLine("	wait 6");
}
outputStream.WriteLine("goto SparkStreamEnd");
outputStream.WriteLine();

// Epilog
outputStream.Close();