var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

var completedDirectionsArray = new Array();
function hasShotInDirection(desiredShootingDirection) {
	for(var i = 0; i < completedDirectionsArray.length; ++i) {
		if(completedDirectionsArray[i] == desiredShootingDirection) {
			return true;
		}
	}
	
	completedDirectionsArray.push(desiredShootingDirection);
	return false;
}

var currentFacingDirection = 0;
function turnToFace(desiredFacingDirection) {
	var turnAmount = desiredFacingDirection - currentFacingDirection;
	while(turnAmount > 32) {
		turnAmount -= 32;
	}
	while(turnAmount < 0) {
		turnAmount += 32;
	}
	if(turnAmount > 0) {
		outputStream.WriteLine("	turncwise " + turnAmount);
		currentFacingDirection = desiredFacingDirection;
	}
}

for(var currentDivisionsCount = 2; currentDivisionsCount <= 32; currentDivisionsCount *= 2) {
	var currentSpacingInterval = 32 / currentDivisionsCount;
	
	for(var currentDivisionNumber = 0; currentDivisionNumber < currentDivisionsCount; ++currentDivisionNumber) {		
		var currentShootingDirection = currentDivisionNumber * currentSpacingInterval;
		if(!hasShotInDirection(currentShootingDirection)) {
			turnToFace(currentShootingDirection, currentFacingDirection);
			outputStream.WriteLine("	attack25 2");
			nextTurnAmount = 0;
		}
	}
}

outputStream.Close();