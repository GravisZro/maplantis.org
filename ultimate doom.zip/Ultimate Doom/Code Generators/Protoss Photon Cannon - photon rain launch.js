var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

// Global variables
	var maxFrameNumber = 4;
	var initialAscensionRate = 10;
	var initialAscensionLevel = 16;
	var maxAscensionLevel = 100;
	var maxSwayFactor = 0.1;
	var swayFactorInterval = 0.05;

// Functions
	function calculatePositionSum(posX, posY) {		
		var sumX = Math.round(posX);
		if(sumX < 0) {
			sumX += 256;
		}
		
		var sumY = Math.round(posY);
		if(sumY < 0) {
			sumY += 256;
		}
		
		var positionSum = sumX + sumY * 256;
		if(positionSum > 32767) {
			positionSum -= 65536;
		}
		return positionSum;
	}
	
	function increaseAscensionRate(currentAscensionRate) {
		return currentAscensionRate * 1.1;
	}
	
	function generateAscensionCode(currentSwayFactor) {
		var currentAscensionLevel = initialAscensionLevel;
		var currentAscensionRate = initialAscensionRate;
		var highestAscensionLevel = currentAscensionLevel;
		var currentFrameNumber = 0;
		
		while(currentAscensionLevel <= maxAscensionLevel) {
			outputStream.WriteLine("	playfram " + currentFrameNumber);
			outputStream.WriteLine("	__04 " + calculatePositionSum(currentSwayFactor * currentAscensionLevel, -currentAscensionLevel));
			outputStream.WriteLine("	wait 1");
			
		// Increment for next frame
			highestAscensionLevel = currentAscensionLevel;
			currentAscensionLevel += currentAscensionRate;
			currentAscensionRate = increaseAscensionRate(currentAscensionRate);
			if(++currentFrameNumber > maxFrameNumber) {
				currentFrameNumber = 0;
			}
		}
		
		outputStream.WriteLine("	sprol0f 373 " + Math.round(currentSwayFactor * highestAscensionLevel) + " -" + Math.round(highestAscensionLevel));
		outputStream.WriteLine("	end");
		outputStream.WriteLine();
	}
	
	function generateRandomStreamBlockCode(minIndex, maxIndex, displayJumpHeader) {
		if(displayJumpHeader) {
			if(minIndex == 1 && maxIndex == currentSwayCount) {
				outputStream.WriteLine("RandomStreamStart:");
			}
			else{
				outputStream.WriteLine("RandomStreamFrom" + minIndex + "To" + maxIndex + ":");
			}
		}
		
		if(maxIndex - minIndex == 2) {
			outputStream.WriteLine("	__1e_condjmp 85 AscendSway" + minIndex);
			outputStream.WriteLine("	__1e_condjmp 128 AscendSway" + (minIndex + 1));
			outputStream.WriteLine("goto AscendSway" + maxIndex);
			outputStream.WriteLine();
		}
		else{
			var midpoint = Math.floor((minIndex + maxIndex) / 2);
			var recurseRightBlock = false;
			
			if(midpoint + 1 < maxIndex) {
				outputStream.WriteLine("	__1e_condjmp 128 RandomStreamFrom" + (midpoint + 1) + "To" + maxIndex);
				recurseRightBlock = true;
			}
			else{
				outputStream.WriteLine("	__1e_condjmp 128 AscendSway" + maxIndex);
			}
			
			if(minIndex < midpoint) {
				generateRandomStreamBlockCode(minIndex, midpoint, false);
			}
			else{
				outputStream.WriteLine("goto AscendSway" + minIndex);
				outputStream.WriteLine();
			}
			
			if(recurseRightBlock) {
				generateRandomStreamBlockCode(midpoint + 1, maxIndex, true);
			}
		}
		
	}

// Program entry point
	var currentSwayCount = 0;
	for(var currentSwayFactor = -maxSwayFactor; currentSwayFactor <= maxSwayFactor; currentSwayFactor += swayFactorInterval) {
		outputStream.WriteLine("AscendSway" + (++currentSwayCount) + ":");
		generateAscensionCode(currentSwayFactor);
	}
	
	generateRandomStreamBlockCode(1, currentSwayCount, true);


outputStream.Close();