var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

function outputGlaveWurmObjectFrame(frameNumber, radius, angle) {
	var xOffset = Math.round(Math.cos(angle) * radius);
	if(xOffset < 0) {
		xOffset += 256;
	}
	
	var yOffset = Math.round(Math.sin(angle) * radius);
	if(yOffset < 0) {
		yOffset += 256;
	}
	
	outputStream.WriteLine("	playfram " + frameNumber);
	outputStream.WriteLine("	__04 " + (xOffset * 256 + yOffset));
	outputStream.WriteLine("	sprol0f 367 0 0");
	outputStream.WriteLine("	wait 1");
}

outputStream.WriteLine("ChooseCoilDirection:");
for(var currentDirection = 0; currentDirection < 31; ++currentDirection) {
	outputStream.WriteLine("	__3c_condjmp " + (currentDirection * 8) + " 8 CoilDirection" + (currentDirection % 16));
}
outputStream.WriteLine("goto CoilDirection15");
outputStream.WriteLine();

for(var currentDirection = 0; currentDirection < 16; ++currentDirection) {
	var angle = 2 * Math.PI / 32 * currentDirection;
	var maxIncrementCount = 5;
	var maxIncrementValue = Math.pow(2, maxIncrementCount)
	
	var currentIncrementValue = maxIncrementValue;	
	var currentRadius = 0;
	var currentFrame = 0;
	
	outputStream.WriteLine("CoilDirection" + currentDirection + ":");
	
// Outward 1
	for(var currentIncrementNumber = 0; currentIncrementNumber < maxIncrementCount; ++currentIncrementNumber) {
		currentRadius += currentIncrementValue;
		currentIncrementValue /= 2;
		
		outputGlaveWurmObjectFrame(currentFrame, currentRadius, angle);
		++currentFrame;
	}
	
// Inward 1
	for(var currentIncrementNumber = 0; currentIncrementNumber < maxIncrementCount; ++currentIncrementNumber) {
		currentRadius -= currentIncrementValue;
		currentIncrementValue *= 2;
		
		outputGlaveWurmObjectFrame(currentFrame, currentRadius, angle);
		++currentFrame;
	}
	
// Outward 2
	currentFrame = 0;
	for(var currentIncrementNumber = 0; currentIncrementNumber < maxIncrementCount; ++currentIncrementNumber) {
		currentRadius -= currentIncrementValue;
		currentIncrementValue /= 2;
		
		outputGlaveWurmObjectFrame(currentFrame, currentRadius, angle);
		++currentFrame;
	}
	
// Inward 2
	for(var currentIncrementNumber = 0; currentIncrementNumber < maxIncrementCount; ++currentIncrementNumber) {
		currentRadius += currentIncrementValue;
		currentIncrementValue *= 2;
		
		outputGlaveWurmObjectFrame(currentFrame, currentRadius, angle);
		++currentFrame;
	}
	
	outputStream.WriteLine("goto CoilDirection" + currentDirection);
	outputStream.WriteLine();
}

outputStream.Close();