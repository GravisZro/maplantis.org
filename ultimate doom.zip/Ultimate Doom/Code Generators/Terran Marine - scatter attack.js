var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

var maxRange = 15 * 16;
var minRange = 3 * 16;
var upshift = 2;

var rangesArray = new Array();
var rangeInterval = 16;
for(var currentRange = minRange; currentRange <= maxRange; currentRange += rangeInterval) {
	rangesArray.push(currentRange);
}

function WriteScatterAttackTarget(maxRange) {
	var rangeInterval = 32;
	var maxBulletCount = 3;
	
	outputStream.WriteLine("ScatterAttackTo" + maxRange + ":");
	
	for(var currentRange = maxRange - rangeInterval * (maxBulletCount - 1); currentRange <= maxRange; currentRange += rangeInterval) {
		outputStream.WriteLine("	attkprojangle " + currentRange);		
		outputStream.WriteLine("	playfram 0x33");
		outputStream.WriteLine("	wait 1");
		outputStream.WriteLine("	playfram 0x22");
		outputStream.WriteLine("	wait 1");
	}
	
	outputStream.WriteLine("	goto ScatterAttackComplete");
	outputStream.WriteLine();
}

outputStream.WriteLine("ScatterAttackStart:");
for(var i = 0; i < rangesArray.length - 1 - upshift; ++i) {
	outputStream.WriteLine("	trgtrangecondjmp " + rangesArray[i] + " ScatterAttackTo" + rangesArray[i + upshift]);
}
outputStream.WriteLine("	goto ScatterAttackTo" + rangesArray[rangesArray.length - 1]);
outputStream.WriteLine();

for(var i = upshift; i < rangesArray.length; ++i) {
	WriteScatterAttackTarget(rangesArray[i]);
}

outputStream.Close();