var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

/*
function generateRandomArcJumpCode(minIndex, maxIndex) {
	var middleIndex = Math.floor((minIndex + maxIndex) / 2);
	
	outputStream.WriteLine("RandomArcJump_" + minIndex + "_" + maxIndex + ":");
	if(minIndex == middleIndex) {
		outputStream.WriteLine("	__1e_condjmp 128 Arc" + arcStepArray[minIndex]);
	}
	else{
		outputStream.WriteLine("	__1e_condjmp 128 RandomArcJump_" + minIndex + "_" + middleIndex);
	}
	
	if(middleIndex + 1 == maxIndex) {
		outputStream.WriteLine("	goto Arc" + arcStepArray[maxIndex]);
	}
	else{
		outputStream.WriteLine("	goto RandomArcJump_" + (middleIndex + 1) + "_" + maxIndex);
	}
	
	outputStream.WriteLine();
	
	if(minIndex < middleIndex) {
		generateRandomArcJumpCode(minIndex, middleIndex);
	}
	
	if(middleIndex + 1 < maxIndex) {
		generateRandomArcJumpCode(middleIndex + 1, maxIndex);
	}
}
*/

var currentFrameNumber = 0;
function generatePlayFrameCommand() {
	outputStream.WriteLine("	playfram " + currentFrameNumber);
	
	++currentFrameNumber;
	if(currentFrameNumber >= 4) {
		currentFrameNumber = 0;
	}
}

var arcStepArray = new Array();
for(var currentArcInitialStep = 1; currentArcInitialStep * 2 - 1 <= 64; currentArcInitialStep *= 2) {
	arcStepArray.push(currentArcInitialStep);
	outputStream.WriteLine("Arc" + arcStepArray.length + ":");
	
	var currentHeightValue = 0;
	for(var currentStepValue = currentArcInitialStep; currentStepValue >= 1; currentStepValue /= 2) {
		currentHeightValue -= currentStepValue;
		outputStream.WriteLine("	shvertpos " + currentHeightValue);
		generatePlayFrameCommand();
		outputStream.WriteLine("	wait 1");
	}
	
	var currentDecrementValue = 1; 
	while(true) {
		currentHeightValue += currentDecrementValue;
		if(currentHeightValue > 0) {
			break;
		}
		
		outputStream.WriteLine("	shvertpos " + currentHeightValue);
		generatePlayFrameCommand();
		outputStream.WriteLine("	wait 1");
		
		currentDecrementValue *= 2
	}
	
	outputStream.WriteLine("goto Arc" + (arcStepArray.length - 1));
	outputStream.WriteLine();
}

/*
outputStream.WriteLine("RandomArcJump:");
generateRandomArcJumpCode(0, arcStepArray.length - 1);
*/

outputStream.Close();