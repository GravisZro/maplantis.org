var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

// Functions
	function calculateFrame(baseFrameNumber, currentDirection, rotationOffset) {
		if(rotationOffset == 0) {
			return baseFrameNumber;
		}
		else{
			var frameAddend = 0;
			
			if(currentDirection <= 17) {
				frameAddend = currentDirection;
			}
			else{
				frameAddend = 32 - currentDirection;
			}
			
			var resultFrame = calculateTargetFrame(baseFrameNumber, currentDirection, rotationOffset) - frameAddend;
			if(resultFrame < 0) {
				resultFrame = 0;
			}
			
			return resultFrame;
		}
	}
	
	function calculateFlip(currentDirection, rotationOffset) {
		if(rotationOffset == 0) {
			return 0;
		}
		else{
			var newDirection = offsetFrame(currentDirection, rotationOffset);
			
			if(newDirection > 17) {
				return 1;
			}
			else{
				return 0;
			}
		}
	}
	
	function calculateTargetFrame(baseFrameNumber, currentDirection, rotationOffset) {
		var newDirection = offsetFrame(currentDirection, rotationOffset);
		var targetFrame = 0;
		
		if(newDirection <= 17) {
			targetFrame = baseFrameNumber + newDirection;
		}
		else{
			targetFrame = baseFrameNumber + (34 - newDirection);
		}
		
		return targetFrame;
	}
	
	function offsetFrame(currentDirection, rotationOffset) {
		var newDirection = currentDirection + rotationOffset;
		while(newDirection < 0) {
			newDirection += 32;
		}
		while(newDirection > 31) {
			newDirection -= 32;
		}
		
		return newDirection;
	}
	
	function calculatePositionSum(currentRadius, currentAngle) {
		var posX = -Math.round(currentRadius * Math.cos(currentAngle));
		var posY = Math.round(currentRadius * Math.sin(currentAngle));
		
		var sumX = posX;
		if(sumX < 0) {
			sumX += 256;
		}
		
		var sumY = posY;
		if(sumY < 0) {
			sumY += 256;
		}
		
		return sumX * 256 + sumY;
	}

// Source data
	var movementRadiiArray = new Array(4, 16, 24, 30, 34, 48, 64, 78, 94, 108, 104, 92, 84, 78, 74, 60, 44, 30, 14, 0, 0);
	var frameNumberArray = new Array(153, 3, 23, 43, 63, 83, 103, 23, 143, 63, 183, 33, 53, 73, 93, 113, 133, 153, 173, 193, 213);

// Program entry point
	for(var currentRotation = 0; currentRotation < 32; currentRotation += 2) {
		var currentAngle = Math.PI * 2 * currentRotation / 32;
		
		outputStream.WriteLine("TrampleBlock" + currentRotation + ":");
		for(var i = 0; i < movementRadiiArray.length; ++i) {
			var currentFrameNumber = frameNumberArray[i];
			var currentRadius = movementRadiiArray[i];
			
			outputStream.WriteLine("	playframno " + currentRotation);
			outputStream.WriteLine("	playfram " + calculateFrame(currentFrameNumber, currentAngle, 0));
			outputStream.WriteLine("	__04 " + calculatePositionSum(currentRadius, currentAngle));
			outputStream.WriteLine("	attkprojangle " + currentRadius);
			outputStream.WriteLine("	__35_condjmp Wait1DisplayTrampleShadow");
		}
		outputStream.WriteLine("goto TrampleBlockEnd");
		outputStream.WriteLine();
	}

outputStream.Close();