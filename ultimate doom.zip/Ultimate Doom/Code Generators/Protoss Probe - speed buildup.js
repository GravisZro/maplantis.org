var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

var currentSpinSpeed = 1;
while(currentSpinSpeed < 13) {
	currentSpinSpeed *= 1.02;
	outputStream.WriteLine("	turncwise " + Math.floor(currentSpinSpeed));
	outputStream.WriteLine("	wait 1");
}

outputStream.Close();