var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

outputStream.WriteLine("TurnFromStart:");
for(var currentDirection = 1; currentDirection < 32; ++currentDirection) {
	outputStream.WriteLine("	__3c_condjmp " + currentDirection * 16 + " 8 TurnBackFrom" + currentDirection);
}
outputStream.WriteLine();

outputStream.WriteLine("TurnToStart:");
for(var currentDirection = 1; currentDirection < 32; ++currentDirection) {
	outputStream.WriteLine("	trgtarccondjmp " + currentDirection * 16 + " 4 TurnTo" + currentDirection);
}
outputStream.WriteLine("goto AttackBegin");
outputStream.WriteLine();

for(var currentDirection = 1; currentDirection < 32; ++currentDirection) {
	outputStream.WriteLine("TurnBackFrom" + currentDirection + ":");
	outputStream.WriteLine("	turnccwise " + currentDirection);
	outputStream.WriteLine("goto TurnToStart");
	outputStream.WriteLine();
}

for(var currentDirection = 1; currentDirection < 32; ++currentDirection) {
	outputStream.WriteLine("TurnTo" + currentDirection + ":");
	outputStream.WriteLine("	turncwise " + currentDirection);
	outputStream.WriteLine("goto AttackBegin");
	outputStream.WriteLine();
}

outputStream.Close();