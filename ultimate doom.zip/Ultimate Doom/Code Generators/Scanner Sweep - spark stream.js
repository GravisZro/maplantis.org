var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

// Public variables
var minDirection = 1;
var directionInterval = 3;

var maxRadius = 125;
var minRadius = 32;
var maxPoints = 7;
var minEndPoint = 7;
var baseAngleTurnAmount = 2 * Math.PI / 64;
var angleTurnAmountInterval = 0;

var streamOutBlockArray = new Array();

// Functions
function StreamOutBlock(_currentDirection) {
	this.direction = _currentDirection;
	this.blockName = "StreamOutDirection" + currentDirection;
	this.generateBlockCode = StreamOutBlock_GenerateBlockCode;
	return this;
}

function StreamOutBlock_GenerateBlockCode() {
	var currentAngle = 2 * Math.PI * this.direction / 32;
	var currentAngleTurnAmount = baseAngleTurnAmount;
	
	outputStream.WriteLine(this.blockName + ":");
	for(var currentPointNumber = 0; currentPointNumber < maxPoints; ++currentPointNumber) {
		var currentRadius = (maxRadius - minRadius) * currentPointNumber / (maxPoints - 1) + minRadius;
		var currentX = Math.round(currentRadius * Math.cos(currentAngle));
		var currentY = Math.round(currentRadius * Math.sin(currentAngle));
		
		outputStream.WriteLine("	imgol08 559 " + currentX + " " + currentY);
		if(currentPointNumber >= minEndPoint) {
			outputStream.WriteLine("	__1e_condjmp 64 StreamOutEnd");
		}
		outputStream.WriteLine("	wait 2");
		
		currentAngle += currentAngleTurnAmount;
		currentAngleTurnAmount += angleTurnAmountInterval;
	}
	outputStream.WriteLine("goto StreamOutEnd");
	outputStream.WriteLine();
}

function generateRandomStreamBlockCode(minIndex, maxIndex, displayJumpHeader) {
	if(displayJumpHeader) {
		if(minIndex == 0 && maxIndex == streamOutBlockArray.length - 1) {
			outputStream.WriteLine("RandomStreamStart:");
		}
		else{
			outputStream.WriteLine("RandomStreamFrom" + minIndex + "To" + maxIndex + ":");
		}
	}
	
	if(maxIndex - minIndex == 2) {
		outputStream.WriteLine("	__1e_condjmp 85 " + streamOutBlockArray[minIndex].blockName);
		outputStream.WriteLine("	__1e_condjmp 128 " + streamOutBlockArray[minIndex + 1].blockName);
		outputStream.WriteLine("goto " + streamOutBlockArray[maxIndex].blockName);
		outputStream.WriteLine();
	}
	else{
		var midpoint = Math.floor((minIndex + maxIndex) / 2);
		var recurseRightBlock = false;
		
		if(midpoint + 1 < maxIndex) {
			outputStream.WriteLine("	__1e_condjmp 128 RandomStreamFrom" + (midpoint + 1) + "To" + maxIndex);
			recurseRightBlock = true;
		}
		else{
			outputStream.WriteLine("	__1e_condjmp 128 " + streamOutBlockArray[maxIndex].blockName);
		}
		
		if(minIndex < midpoint) {
			generateRandomStreamBlockCode(minIndex, midpoint, false);
		}
		else{
			outputStream.WriteLine("goto " + streamOutBlockArray[minIndex].blockName);
			outputStream.WriteLine();
		}
		
		if(recurseRightBlock) {
			generateRandomStreamBlockCode(midpoint + 1, maxIndex, true);
		}
	}
	
}

// Program entry point
for(var currentDirection = minDirection; currentDirection < 32; currentDirection += directionInterval) {
	var streamOutBlock = new StreamOutBlock(currentDirection);
	streamOutBlockArray.push(streamOutBlock);
}

generateRandomStreamBlockCode(0, streamOutBlockArray.length - 1, true);

for(var i = 0; i < streamOutBlockArray.length; ++i) {
	var streamOutBlock = streamOutBlockArray[i];
	streamOutBlock.generateBlockCode();
}

// Epilog
outputStream.Close();