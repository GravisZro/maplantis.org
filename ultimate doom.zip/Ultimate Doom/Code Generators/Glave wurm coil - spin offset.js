var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

var positionCount = 0;
function outputGlaveWurmObjectFrame(frameNumber, radius, angle) {
	var xOffset = Math.round(Math.cos(angle) * radius);
	if(xOffset < 0) {
		xOffset += 256;
	}
	
	var yOffset = Math.round(Math.sin(angle) * radius);
	if(yOffset < 0) {
		yOffset += 256;
	}
	
	outputStream.WriteLine("DamageLoopStart" + (positionCount++) + ":");
	outputStream.WriteLine("	playfram " + frameNumber);
	outputStream.WriteLine("	__04 " + (xOffset * 256 + yOffset));
	outputStream.WriteLine("	sprol0f 367 0 0");
	outputStream.WriteLine("	domissiledmg");
	outputStream.WriteLine("	wait 1");
}

function randomJumpToPosition(minPosition, maxPosition) {
	var middlePosition = Math.floor((minPosition + maxPosition) / 2);
	
	outputStream.WriteLine("DamageLoopRandom_" + minPosition + "_" + maxPosition + ":");
	if(minPosition == middlePosition) {
		outputStream.WriteLine("	__1e_condjmp 128 DamageLoopStart" + minPosition);
	}
	else{
		outputStream.WriteLine("	__1e_condjmp 128 DamageLoopRandom_" + minPosition + "_" + middlePosition);
	}
	
	if(middlePosition + 1 == maxPosition) {
		outputStream.WriteLine("goto DamageLoopStart" + maxPosition);
	}
	else{
		outputStream.WriteLine("goto DamageLoopRandom_" + (middlePosition + 1) + "_" + maxPosition);
	}
	
	outputStream.WriteLine();
	
	if(minPosition < middlePosition) {
		randomJumpToPosition(minPosition, middlePosition);
	}
	
	if(middlePosition + 1 < maxPosition) {
		randomJumpToPosition(middlePosition + 1, maxPosition);
	}
}

outputStream.WriteLine("DamageLoop:");

var maxSpokes = 30;
var currentRadius = 12;
var frameNumber = 0;
var radiusIncrementValue = 0.1;
var radiusIncrementDirection = 0.1;
for(var rotationIteration = 0; rotationIteration < maxSpokes; ++rotationIteration) {
	currentRadius += radiusIncrementValue;
	radiusIncrementValue += radiusIncrementDirection;
	if(Math.abs(radiusIncrementValue) > 1) {
		radiusIncrementDirection *= -1;
	}
	
	outputGlaveWurmObjectFrame(frameNumber, currentRadius, 2 * Math.PI * (rotationIteration / maxSpokes));
	
	++frameNumber;
	if(frameNumber >= 10) {
		frameNumber = 0;
	}
}

outputStream.WriteLine("goto DamageLoop");
outputStream.WriteLine();

randomJumpToPosition(0, positionCount - 1);

outputStream.Close();