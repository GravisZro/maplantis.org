var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

for(var spinSpeed = 1; spinSpeed <= 11; ++spinSpeed) {
	outputStream.WriteLine("SpinKamikazeC" + spinSpeed + ":");
	outputStream.WriteLine("	__1e_condjmp 50 SpinKamikazeC" + (spinSpeed + 1));
	outputStream.WriteLine("	turncwise " + spinSpeed);
	outputStream.WriteLine("	wait 1");
	outputStream.WriteLine("	goto SpinKamikazeC" + spinSpeed);
	outputStream.WriteLine();
	
	outputStream.WriteLine("SpinKamikazeCC" + spinSpeed + ":");
	outputStream.WriteLine("	__1e_condjmp 50 SpinKamikazeCC" + (spinSpeed + 1));
	outputStream.WriteLine("	turnccwise " + spinSpeed);
	outputStream.WriteLine("	wait 1");
	outputStream.WriteLine("	goto SpinKamikazeCC" + spinSpeed);
	outputStream.WriteLine();
}

outputStream.Close();