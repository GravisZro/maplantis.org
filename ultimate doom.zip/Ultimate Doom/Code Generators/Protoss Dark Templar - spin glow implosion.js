var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

var maxGlowPoints = 3;
var maxGlowDivisions = 3;
var currentRadius = 16;
var radiusDecrementAmount = currentRadius / maxGlowDivisions / 2;

while(currentRadius >= 1) {
	for(var currentGlowDivision = 0; currentGlowDivision < maxGlowDivisions; ++currentGlowDivision) {
		var currentAngleBase = Math.PI * 2 * currentGlowDivision / maxGlowPoints / maxGlowDivisions;
		for(var currentGlowPoint = 0; currentGlowPoint < maxGlowPoints; ++currentGlowPoint) {
			var currentAngle = currentAngleBase + Math.PI * 2 * currentGlowPoint / maxGlowPoints;
			outputStream.writeLine("	imgol08 443 " + Math.round(currentRadius * Math.cos(currentAngle)) + " " + Math.round(currentRadius * Math.sin(currentAngle)));
		}
		outputStream.writeLine("	wait 2");
		currentRadius -= radiusDecrementAmount;
	}
}

outputStream.Close();