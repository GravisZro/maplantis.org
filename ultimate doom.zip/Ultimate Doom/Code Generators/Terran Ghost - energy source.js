var fso = new ActiveXObject("Scripting.FileSystemObject");
var outputFileName = fso.GetParentFolderName(WScript.ScriptFullName) + "\\" + fso.GetBaseName(WScript.ScriptFullName) + ".genicc";
var outputStream = fso.CreateTextFile(outputFileName, true);

for(var currentRadius = 32; currentRadius >= 0; currentRadius -= 8) {
	for(var currentRotation = 0; currentRotation < 6; ++currentRotation) {
		var currentAngle = currentRotation * 2 * Math.PI / 6;
		outputStream.WriteLine("	sprol0f 373 " + Math.round(currentRadius * Math.cos(currentAngle)) + " " + Math.round(currentRadius * Math.sin(currentAngle)));
	}
	outputStream.WriteLine("	wait 1");
}

outputStream.Close();