Description
-------------------------------------------------------------------
Ultimate Doom is the answer to all your requests to combine the three mods of the Doom series - Doom Dragoon, Terran Doom and Zerg Doom - into one StarCraft mod so you can play it against your friends! The Doom series was created to demonstrate iscript-based modding techniques and so you'll see a lot of what iscript modding is capable of in this mod.


How to use
-------------------------------------------------------------------
Just run "Ultimate Doom.exe" and play a game. If you've got StarCraft installed properly it should all work from there.


Version information
-------------------------------------------------------------------
This is Ultimate Doom prerelease 3, released July 2007. The only other public version has been Ultimate Doom prerelease 2, released 2005, which was much more buggy and unbalanced. Hopefully that's changed.


Background
-------------------------------------------------------------------

Every Doom mod so far has always introduced some new, revolutionary techniques to the modding community. It's been a journey, it took time to discover/invent the techniques in each mod, and as time has passed, the effects have consistently got more complicated.

In Doom Dragoon, all of the basic iscript effects you see now were first introduced to the world. Those are things like, jumping, spinning, random attacks, scattered bullets and to-range attacks like the Dark templar's psionic vortex. Although it took me three years and a lot of discoveries to get to the level where I could discover those techniques, by today's standards those techniques are standard ones everyone should know. After Doom Dragoon, iscript modding was unlocked, and now the research made public in Doom Dragoon has become commonplace. Modders these days do not even consider these effects praiseworthy. 

Terran Doom saw a huge focus on to-range attacks, with the Valkyrie's pulse cannon, Firebat's anti-matter missiles and the Battlecruiser's Yamato all using a variation on the technique. The two biggest discoveries for this mod was the true meaning of the attkprojangle command, which I used to create the scattered bullet effect of the Marine; and finding out how to make units with turrets shoot while moving.

Zerg Doom had a number of new discoveries. One of the most revolutionary would be the Guardian's acid trails, where a weapon continues to cause damage at a location after it has hit. This effect was such a hit that variations on this original idea are seen in many of the most popular mods today. Another new effect was the Infested Terran's 360-degree attack, which has also now become a favourite among modders. The most difficult effect that I have yet to see replicated is the Ultralisk's trample effect, where the Ultralisk actually walks over its target during its attack. To be honest, I think this one is the most revolutionary effects of all the Doom mods because for years I had told people this was just simply not possible. I couldn't wait to show the world that it was possible, but it turns out that these days people have come to expect the unexpected from the Doom mods so not many people understood the ingenuity required to construct such an effect. There were some other minor new discoveries in this mod, things like getting the Sunken Colony's tentacles to scatter and getting the Lurker's subterranean spines to move differently.

Ultimate Doom is the final mod in the series. Unfortunately there hasn't been much left to discover, but I still managed to find new things. The biggest thing was that I finally have come to understand how different image overlays in the same sprite interact. This is different from the other discoveries because it's more like a concept, not a technique in itself, and so it's actually just lots of pieces of knowledge stuck together. The only thing about this concept is it is relatively technical, so only really if you are well-versed in the limits of StarCraft modding will you see things and go "wow, I didn't even know that was possible." It's hard to appreciate otherwise. But the best places to see it in action is for the Siege Tank (in siege mode), Ghost and Ultralisk. 

For the Siege Mode Siege Tank, when it performs its new Arclite Spray attack, where the turret goes back into tank mode independent of the base which remains in siege mode, the only way I managed to keep that in sync was because of this new understanding of how image overlays interact. I think that the whole idea of having a Siege turret go back into a tank turret in the middle of an animation is definitely new. If I hadn't discovered that all the image overlays in the same sprite face the same direction, it wouldn't have been possible to create this effect without spending ages editing a GRP file or something. I would also like to make a special mention because I believe this is the hardest effect I've ever done, and after all of the iscript I've done trying to push all those limits and do the impossible, I think that really says something.

For the Ghost, the Ghost clones only disappear when the attack animation is finished, and that's done because I discovered that all image overlays in the same sprite get sent the same animations if they are set to receive the full set of animations in images.dat. It blew me away really, there's no such thing as a main image overlay I realised, every overlay is just as important as the next. The Ultralisk is the same idea - its shadow now follows it when it tramples, and that's only possible because of the same discovery.

I used the new concept in several other places, the Firebat, the Archon, Acid Spores, the Hydralisk and other places, but I don't think you'll notice that unless you really try to analyse how I did them. The whole concept also allows you to save on sprites in some cases, which is very useful when you're quickly reaching the sprite limit.

I truly am very glad to have discovered how this overlay interaction works, because for a long time there was a part of the iscript that I couldn't understand, like how engine overlays knew to disappear when a unit stops or why the Firebat doesn't have a nobrkcodeend instruction in its iscript. When I worked this out I felt as if it completed my knowledge of iscript editing and so I'm glad to make this last mod with no questions left unanswered. 

There were also a few other discoveries. I had worked this one a while ago, but I found a way to make Psionic Storm last longer. So much for people telling me that was hard-coded and unchangeable. Another thing I discovered was in this mod was how to make a weapon pause before it starts moving, which I used for the psionic vortex, and also how to make size-dependent attacks for melee units, for example the Broodling will only turn small enemy units into infantry, large units and buildings will be ignored.

Two new ideas in this mod is the idea of weapons that travel funny, like the Phase Disruptor and the Glave Wurm, and weapons that bounce on the ground, like the Fragmentation Grenade. Two other things in this mod were not discovered by me, but I'm sure they'll be more popular now that they've been in a Doom mod. JarqaFelmu was the one who introduced me to the idea of the warp flash palette in images.dat, and DiscipleOfAdun showed me the __37 command which allows you to change the flingy.dat speed of a unit, which is truly a remarkable discovery.

So I am really glad to present the completed version of Ultimate Doom, I know you've all been asking me to do it for ages. I've called it "Prerelease 3" because it still crashes occassionally, but I still haven't found out why. If you ever do find out why, please email me, I'm bstrhino on gmail, and let me know, because I really do want to know.

-BSTRhino



To modders
-------------------------------------------------------------------

To help out you budding modders, I've included all of the source iscripts and for the first time ever I've included my iscript code generators. As you can see I have used JavaScript and Microsoft Excel to piece together all the repetitive parts of the code, I hope it inspires you. Please also feel welcome to decompile the MPQ and see how parts are done. Also if you want to, you could make your own attempt at balancing the mod and release your own rebalanced version of it, just don't forget to credit me for making the mod.



Change list
-------------------------------------------------------------------

Scanner sweep
- Different graphics

SCV
- Weapon is now self-destruct, has high splash range. 

Marine
- At shorter ranges, the Gauss Rifle scatters and causes collateral damage.
- Grenade fires randomly (explosive)

Firebat
- Flame thrower is now a constant stream.

Ghost
- Laser standard weapon (concussive)
- Psi-clone attack, melee range. The Ghost creates psionic clones of itself, and all the clones concentrate their energy to create one strong energy beam that causes heavy damage. Designed to destroy buildings with ease. I know someone specifically gave me this idea but I can't remember who it was sorry.
- Lockdown now targets anything.

Vulture
- Scattered fragmentation grenades (concussive)
- Now actually looks like it hovers.

Siege Tank (tank mode)
- Same weapon stats, but now the Arclite cannon is a laser.

Siege Tank (siege mode)
- Arclite shock cannon now hits in a scattered area around target, making it more suited to larger units, especially buildings. Also now fast moving units can outrun the arclite explosion as there's a delay between targetting and attacking.
- New arclite spray cannon. The siege turret moves back into non-siege position and fires a linear stream of explosives.

Goliath
- Hellfire missiles have splash.

Wraith
- Burst lasers fire in triplets - they're more "burst" now.

Battlecruiser
- Laser Battery does much more damage to smaller units.
- Yamato gun damages everything in its path.

Valkyrie
- Pulse cannon damages everything in its path.

Missile turret
- Triple missile volley, causing collateral damage.

Spider mine
- High non-friendly concussive damage against units close to the explosion. Also releases 360-degree energy radiation to a longer range which only hurts enemy units.

Drone
- Can attack anything on the entire map but only does a small amount of damage.

Zergling
- Attacks now always do full damage regardless of enemy armor.
- Along with regular claws, the Zergling also has a special jump strike which does additional damage.
- Cosmic puke damages a stream of units in front of the Zergling. 
- Hyper speed when the Zergling has been travelling for a long distance.

Hydralisk
- Needle spines sometimes fire twice.
- Small chance of Hydralisks causing five times normal needle spine damage - designed to be activated when Hydralisks are in large groups.
- Firebreath - explosive stream of damage best suited to destroy large-sized enemies.
- Tornado spin at short range

Lurker
- Subterranean spines do massive damage against infantry.
- Attack out and back

Mutalisk
- Glave wurm coil causes constant damage on enemies - augmented very strongly by devourer acid spores.

Guardian
- Acid spores leave acid trails

Devourer
- Corrosive acid bounces

Scourge
- Ranged suicide attack - the scourge turns into a bolt of green energy and attacks the target.
- Now attacks ground.

Queen
- Parasite now bounces

Defiler
- Plague remains in an area for a while, infecting any units that walk by.

Broodling
- Sometimes uses a spawn broodling attack, but only on smaller units.

Infested terran
- Super yamato explosion

Sunken colony
- Subterranean tentacles scatter

Spore colony
- Seeker spores splash

Probe
- Self destruct

Zealot
- Zealot rage special attack - the Zealot spins around to strike its target with momentum, causing a shockwave. This is set to never happen as the Zealot's first attack on an enemy and the chance of the Zealot using this attack is dependent on what it's attacking. It has a higher chance of rage when attacking a large unit such as a tank or ultralisk, a lower chance on infantry and buildings, and the lowest chance on static defenses.

Dragoon
- Phase disruptor scatters and can miss the target, so it is necessary to have a group of Dragoons to be effective.
- Jump cannon is triggered at short range. This attack never misses and does high damage to infantry, but the Dragoon is set to not use this against melee units that are attacking it for balance reasons. This makes Zealots and Zerglings effective against unprotected Dragoons, but Firebats attack from a short range and so can still be struck by the infantry-killing jump attack. 

High templar
- Psionic storm lasts longer

Dark templar
- Warp blades do high damage against infantry units, killing the weaker ones in one swipe. Great for stealth attacks. The warp blades also release bouncing energy at the same time.
- Psionic vortex, where energy is projected forward, is triggered randomly.

Archon
- Focuses energy constantly on target without stopping
- Sometimes releases a short-range radial energy blast that causes heavy damage to units standing close to the archon.

Observer
- Switches to hyper speed after it has been travelling a certain distance.

Reaver
- Scarabs travel on all terrain
- Scarabs send out bouncing energy bolts

Scout
- Dual photon blasters are very powerful against infantry, but have a much shorter range

Carrier
- Interceptors do damage in a wide scatter and splash range

Corsair
- When close to an enemy air unit, may randomly send out psionic radiation, causing major damage to enemy air within the area

Arbiter
- High power long-range psionic shockwave attack. Does more damage the longer the distance between the Arbiter and the target - meaning most units that attack the Arbiter won't get the full power of the Arbiter's psionic shockwave unless you micromanage. 

Photon cannon
- Photon rain