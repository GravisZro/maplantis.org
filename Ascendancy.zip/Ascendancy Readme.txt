Ascendancy is a mod by Lord_Agamemnon(MM), that is to say, me.
Steal it and you will die, slowly and painfully.

This mod runs only on Starcraft 1.14.

KNOWN BUGS:
None at this time.

VERSION HISTORY:

V 1.26
Made the AI blank so people will stop bitching about it.

V 1.25

Decreased cost for upgrading to Tier 3 to 12 minerals.
Weakened worker attacks.
Decreased Angel Gate range and damage to 10.
Removed the Emergent and Avatars' ability to attack air.
Fixed a couple graphical bugs.
Fixed the "Puffy Cloud Bug" that could render Avatars and Abyss Walkers useless.
Changed the Magus' ability to Illusory Time (Ensnare)
Changed the Abyss Walker's Antienergy ability to Fallen One (Destroys an Angel Gate)
Transfiguration Orbs are now ground units with 100 shields in addition to their 100 health and 5 armor.

V 1.1

Removed Angel Gate shields, increased HP to 150, and added regeneration.
Changed a couple strings for great justice.
Added a title screen.
Changed EXP (Minerals) earned per Tier 2 and 3 kill.
Corrected a bug with EXP gain triggers.
Increased Benedictor cost and build time, decreased Rift Nexus build time.

V 1.0

Release!

CREDITS:
Me, Lord_Agamemnon(MM): No, duh.
SquareSoft: the title screen background is sporked from the Wikipedia article on FFVII Characters.

ACKNOLEDGEMENTS:
Blizzard Entertainment, for making me despair consantly.
Staredit.net for dying and jolting me back into the modding community.