The Remnant is a mod by me, Lord_Agamemnon(MM).
Steal it, and I will send Outlaws after you.  Yes, the guys with meat hooks.

IMPORTANT: I know the Grunts will sometimes get stuck in buildings; there is nothing I can do about this.
Hitting the "Stop" button will get them unstuck.

Graphics credits:

-Fortress, Seedy Tavern, Vault: Blizzard Entertainment
-Shelter, Alchemy Warrior: Ermac
-Scout: Hog Farmer Bob
-Outlaw: S1andS2
-Officer: [Creator Unknown]
-Dirigible: Peak Man
-Iron Titan: Lord_Agamemnon(MM)

Version History
================================
None yet :P