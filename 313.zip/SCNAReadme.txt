SCNA Readme

This is a mod created and devoloped by modmaster50 and RoryFenrir.

Installation:
-Unzip the contents of the zip file into your starcraft directoy
-Make sure you are using SC v1.15.1
-Run SCNA.exe for the game, run SCNAEdit.exe for the editor

To update SCNA, run the patcher file downloaded and specify your install directory.

Files Included:
-SCNA-1.0b.exe (main exe injector)
-SCNAEdit.exe (SCNA map editor)
-SCNAReadme.txt (this file)

Credits:
modmaster50 - Executive Producer
RoryFenrir - GRP Artist

IMPORTANT - WHO AM I SYSTEM (DIABLED IN LIGHT EDITION)
P1 = Scantid
P2 = Kakaru
P3 = Ragnasaur
P4 = Ursadon
P5 = Civilian
P6 = Queen
P7 = Defiler
P8 = Vessel

Graphics:
I did not make ANY of these GRPs. I am not the creator (mostly downloaded from the Maplantis database). Thank you to all of the GRP makers!

Alpha Testers:
modmaster50
RoryFenrir
Deathman101

Version History:
SCNA Light Edition 1.0b
-fixes major bugs
-adds more wireframes
-adds more icons

SCNA Light Edition 1.0a
-adds campaign units (campaign not implemented, so only available in editor)
-trigger systems diabled (until full edition)
-adds wireframes
-adds more icons
-adds more portraits
-update to SC1.15.1

Beta v1
-changes some attacks
-adds more strings

Alpha v8
-Adds more units and buildings

Alpha v7b
-Fixes replay crash problem

Alpha v1 - v7a
-Mod still being built

THE UNITS
TERRAN:

Avenger - Light flyer
Ground/Air - Flechette Shotgun

Rocket Trooper - Anti-tank infantry
Ground - Shockwave Missiles

Harbinger - Heavy planetary vehicle
Ground - Flechette Grenade
Air - Shockwave Missles

Warcruiser - Capital ship
Ground/Air - Yamato Gun
Special - Laser Barrage

ZERG:

Crawler - Heavy ground unit
Ground/Air - Acid Spore
Special - Fire Breath

Leviathan - Capital ship (well, its organic)
Ground/Air - Acid Bomb

Deathmonger - Spellcaster
Air - Diseaser Spore
Special - Lava Burst

Eviscerator - Heavy ground unit
Ground/Air - Glaive Wurm
Special - Acid Spray

PROTOSS:

Knight Templar - Heavy infantry
Ground - Dual-edged Psi Blade

Ravager - Heavy artillery
Ground/Air - Phase Disrupter Cannon
Special - Pulse Shockwave

Marauder - Bomber
Ground - Anti-matter Bombs

Vindicator - Capital ship
Ground/Air - Warp Beam
Special - Atomic Disruption Cannon

THE BUILDINGS
TERRAN:

Starbase - Factory building

Ion Cannon - Defensive addon

Accelerator - Factory addon

Weapons Center - Upgrade addon

ZERG:

Overmind - Factory building

Cerebrate - Upgrade building

THE CAMPAIGN STUFF
TERRAN:

Grenadier (UED) - Heavy infantry
Ground - Flechette Grenade
Air - STA Laser Cannon
Special - Deploy Laser Drone

Repair Bot - Worker
Ground - Fusion Cutter

Battle Droid (Dominion) - Heavy infantry
Ground/Air - Dual Wrist-blasters

Starstation - Capital ship / Main base
Ground/Air - Laser Battery

Combat Center - Factory building

PROTOSS:

Soul Templar - Spellcaster
Special - Warp Sphere

Dome Temple - Factory building

Enjoy!