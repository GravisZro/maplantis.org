EDITED TERRAN CARGO SHIP
By Soul Filcher (soulfilcher@yahoo.com)

This is the GRP file for the modified "Cargo Ship". An unused unit.
Use it as you see fit.