Hover Tank

==============================
Assembly:
This .zip contains a base grp file and a turret grp file which can be used.
Just have a unit that has turret capacity (Siege Tank for instance)
and replace the original grps with these.

This .zip does not contain any weapons data or something like that.
==============================

