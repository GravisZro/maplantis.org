
Project Miranda is a mod by Lord_Agamemnon(MM).  Do not steal it.

NOTES:
This mod is only compatible with Starcraft version 1.14.

Known Bugs:
Minesweepers explode if they switch modes over buildings.  There is nothing I can do about this.
There may be...instabilities when a game is being created or has just started.  I can't do anything about this either.
A worker will sometimes be stranded on/under a completed buildings.  Hit "Stop" to return it to normal.

------------------------------------------------------------------------------------------------------------------------
CHANGE LOG/VERSION HISTORY:

Release 1.3
Decreased Acidbat health to 10.
Made Artillery Ship air attack 1 16-damage attack instead of 3 8-damage ones
Increased Witchkiller health to 45
Removed the ability to upgrade the Acidbat's attack
Increased Xavoren damage to 6 and changed attack type to "Normal"
Decreased Acidbat speed.

Release 1.2
Fixed the Destriant's Energy Syphon ability, and thereby the whole unit.  Use it, people.
Fixed the Field Operative's supply.

Release 1.1
Fixed the damn nuke glitch
Made Witchkillers Medium size rather than Large
Fixed the morph-cancel desync, I think.  I personally think it was just someone having the wrong version, but...
Decreased Chemical Lab HP to 200
Increased Dimensia Crystal HP to 100

Release 1.05
Fixed a bug that would caused the Xavoren to crash
Fixed a bug that prevented the building of Nihilists
Fixed a bug pertaining to the Cancelled Morph

Release 1.0
RELEASE!

Beta 2.98
The desync bug is finally fixed.
Changed a couple more things regarding unit statistics.
Completed unit index.  Please read it :P
Fixed a couple wireframes that had their colors messed up.
Added the Blast Shell ability to the Inquisitor.
Gravity Wells now provide cloaking to nearby units.
Dimensia Crystals now attack air and ground.
Included the Aegis and dependencies thereon.

Beta 2.92
Changed a couple little things.
Restored resource scaling to normal SC (i.e. gas mines in 8's instead of 1's, and costs are in 50's rather than 8's).
Made Pacifier attack damage normal type.
*Points finger at Protoss buildings* I'm on to you, Mr. Desync Bug!

Beta 2.9
Added wireframes.
Messed around with a couple things, fixed a couple crashes
I hope I've fixed the desync problem.  Apparently not...

Beta 2.8
Completed icons and accepted Corbo's offer of a .bin file.
Looks like everything except wireframes and balancing is done.
Stat_txt.tbl is practically finished.
Added Continuum Restorers.
Messed around with .lofs, so they now work and look right.
Changed graphics, name, and weapon appearance of the Starfighter to the Atrean Paladin.

Beta 2.7
OK, mostly everything's in place.  Icons and wireframes are still missing, so they're next.  Then polishing.
Changed stat_txt.tbl properly, except for something I haven't thought of a good name for and the whole ranks mess.
The Mirandites are basically finished, AGAIN.

Beta 2.WTF
Eep.  No clue WHERE the hell I am version-wise.
Nerien Guard added, mostly.
Mirandites scrapped and added again.
Galactic Armada now features the Atreans, those cunning rascals, and has several name changes.

1.8: (BETA)
Oh boy.  People liked Stratosphere so much that I scrapped most of my previous work and made Strato one of the races.
Added the Nerien Guard.
The Humans are now called the Galactic Armada.
Minesweeper Orbs are now called Minesweepers and are detectors in both modes.
Gunmen now deal 6 damage instead of 7.
Aeromines are now built at the Missile Launchpad.  The Demolition Lab enables their construction.
Removed Cryomines.  No one used them anyway.
The Armada expansion building is now the same as the starting building and is called the Field HQ.
Lackeys are now called Field Operatives.  Couple other name changes.

------------------------------------------------------------------------------------------------------------------------
STRATOSPHERE VERSION HITSTORY:

1.1:
Reduced Minesweeper Orb armor to 2 and increased its cooldown time to 37.
Added a mode-change animation for the Minesweeper Orb.
Changed a couple strings.

1.0:
RELEASE!
Increased High-Yield Bomb damage to 25 and changed explosion to Splash(Radial).
Decreased Heavy Bomber health to 60.
Increased Aeromine and Cryomine attack range to 4.

0.9.8:
Tested some balance, huzzah.
Players now start with 10 minerals instead of 30.
Fixed a nasty bug with the Saboteur.
Fixed various string bugs.
Fixed various bugs relating to upgrades.
Fixed (I think) a bug with the Minesweeper Orb that would crash the game.
The AA Missile Battery (Floor Missile Trap) is now the Particle Cannon (Missile Turret) and its attack is 1x10 rather than 2x10.
The Minesweeper Orb's attack now fires as 10x1, not 5x2.
The wireframe changes are now complete.
The Artillery Ship now uses Plasma Railgun, which splashes Acid Spores, as an air attack instead of Proton Accelerator.
The Mines now have a reasonable Target Acquisition Range.
Shockbolt (Lockdown) now costs 150 energy instead of 100.
Increased Gunman attack to 7.
Decreased Minesweeper Orb health to 45, removed its spellcasting ability, and made Turret Mode a detector.
Increased Lackey armor to 2.
Increased Watcher count to 4 and decreased sight range to 5.
Increased City health to 350.

0.9.5:
w00t, almost release time!  All that remains is balance testing.

------------------------------------------------------------------------------------------------------------------------
GRAPHICS CREDITS:

Main menu layout: Corbo(MM)
Armada Pacifier: StormWatch
Armada Saboteur: S1AndS2
Nerien Acolyte: Hog Farmer Bob
Mirandite Scuttler: Originally Ermac, modified by Lord_Agamemnon(MM)
Mirandite Adjutant; Nerien Ostiary; Chronoreaver: Ermac
Nerien Ambassador, Viper, Inquisitor, and Nihilist: Peak Man
Armada Base, Bomber, and Aeromine; Nerien Caravan Ship: Blizzard Entertainment
Nerien Riftgate Psi and Supply Gate: Kookster
Mirandite Kyrion and remnants, Drone Source/Droneswarm/Defender: Voyager7456(MM)

And, of course:
Armada Adept, Paladin, and Artillery Ship; All Mirandite buildings, Qeranax, and Xavoren;
Nerien Riftgates Alpha, Zeta, and Sigma, Tetrine Blocker, Dimensia Crystal (based on a Blizzard original), Gravity Well,
Terratherion, Blood Seraph, and Daemonstar; Neutron Cannon; Continuum Restorer:
LORD_AGAMEMNON(MM)

Any graphics not credited are made by Blizzard Entertainment.

If you wish to use a graphic made by me, ask my permission.  Others are property of their repsective creators.

-----------------------------------------------------------------------------------------------------------------------
SPECIAL THANKS:
Everyone, for waiting so long for this mod.
Doodle77 and scwizard, for their slavish devotion to Stratosphere :P
scwizard, for helping me beta test.
Hercanic, for instructing me in the ways of game design and giving me the idea that got Project Miranda started.
Blizzard Entertainment, for making Starcraft.
The good folk of Staredit.net and Maplantis.org, for playing my mods.
My father, for playing SC with me :O
DiscipleOfAdun, for making Firegraft, even if it isn't finished yet.

Starcraft and Starcraft: Brood War are copyright Blizzard Entertainment.