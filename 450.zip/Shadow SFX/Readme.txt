So far I ripped 30 StH sfx/voices. I have 4 extra because
I split apart Chaos Control and Chaos Blast into 4 other files.
I hope to rip more if possible(most were ripped from movies and
the flash site). =~.^=

Ripped by Aisha Clan-Clan Prower.

