Scorpion Tank + Flamer Tank

The Scorpion:
A newer design from the Cobra Tank that has missiles on it's turret to attack aircraft.

The Flamer:
Flamer tank, strong vs buildings due to it's high temperature flamer.

Both will also be featured in the Warzone2100 Mod

Important Note:
The 'unit\terran\tank.lol' file in this .zip also has to be used for the Cobra Battle Tank to have the turret being placed ok.

This .zip contains:

- FlamerBase.grp
- FlamerTurret.grp
- ScorpionBase.grp
- ScorpionTurret.grp
- Readme
- Image of both Scorpion and Flamer
- Image of Scorpion
- Image of Flamer
- Tank.lol (places the Turret at the right place of base.)

Also usable for the Terran army
Made by: Scourge_splitter