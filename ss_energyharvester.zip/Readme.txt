GRP Graphic Change
By Scourge Splitter

Energy Harvester from the Celareon Conversion
Currently only 1 frame but I'm yet working on one where it has movement when idle or working on reserches.

This zip file only contains the .GRP, this readme and a bitmap.
----------------------------------------------------------------------------------------------------------