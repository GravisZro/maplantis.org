These files when placed in your Starcraft Folder will downgrade SC to v1.15.0.

**** NOTE ****
Obviously backup your original files before placing these in your Starcraft folder or you will lose/overwrite your current patch.  