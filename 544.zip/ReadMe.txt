===================================
Celareon Conversion Beta Verson 2.0

By Scourge_Splitter
===================================
Installing
===================================
Extract the files and place them somewhere of your desire.
The Mod is made with the first Firegraft and therefore needs version 1.15.0

a downgrade kit to downgrade to ver. 1.15.0 is uncluded.
When you have downgraded to the correct version you kan doubleclick the "Celareon Conversion Beta ver 2.exe" and the game will start, it is also self supporting so only the original StarCraft: Broodwar disk is required.
===================================
Mod story
===================================
The Celareon conversion is set in an unknown timeline in an unknown universe where a total of 4 races are featured.

Cyrex Zerg Alliance.
The Zerg have returned twice as hard and now they even bring an evenly vile counterpart cebernetic ally known only as the Cyrex Collective.

Talon Empire.
The mighty empire of the Talon which is build by the two great tribes which follow a destictive way of thinking. They have had everlasting war with each other in the past but now fight as one but are twice as dangerous.

Celareon.
One of the greatest evolved races you can come acros, having shed their biological bodies they exist as pure energy and rely on exoskeleton bodies to travel though the vast space. Through the Alliance who invaded their world they were drawn into an epic conflict which cannot bare the sight of light.
===================================
notes
===================================
This beta version 2.0 is yet under construction for perfection
since the last version several things have been fixed and added.

it features many aspects:
- dangerous AI, highly adaptive and very versatile. Even capable of constructing the greatest feared weaponsystems.
- Complete modification for Terran ad Protoss races, Zerg original has been extensively adapted to fit in their new role.
- Extensively changed stats and graphics (not 100% yet)
- Extensively changed technology tree.
- all together (all 3 races) one can construct about 62 buildings and 58 units.
- about 20 more heroes can be used in story mode.
- more information can be found on the Celareon Conversion website: www.members.lycos.nl/celareonconversion (currently not up to date according to this version.)