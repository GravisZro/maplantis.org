This is a study of the potential a grafted Ai can produce when the player and computer control different units and meant to be nothing more.  There is no attempt to make this "playable" or fix strings etc.  What can be done with this concept tho is another story.  SO GET BUSY MAKING BETTER AI's for your mods! :O

ASAI_FG is a Firegrafted version and thus requires SC 1.15
ASAI_110 is a 1.10 memgraft version and thus requires SC 1.10


ASAI v1.02:
Protoss Doomsday Carrier added.  

ASAI v1.01:
A jacked up Terran Ai in response to Iskatu Mesk's desire for "quick" spidermines and siegemode as a potential AO counterpart/test.

www.BroodWarAi.com
for more details.



