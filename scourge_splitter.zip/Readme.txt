The Scourge Splitter.

In this mod you see what I had before my eyes for the Scourge Splitter unt as possibly also will be featured in the Maplantean War.
