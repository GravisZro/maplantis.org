Edited Ghost
by Rezon v2
superkwan@aol.com
http://alliance.net-games.com/main.shtml

This portrait is exclusive to The Star Alliance, which is your source for 
the ultimate custom gaming experience.  You cannot upload this onto your
site without permission from me.  But if you use it in your campaign or
project, you do not have to give any credit to me or The Star Alliance at
all, although it would be appreciated if you did.  

To use this, replace each file with its proper filename in StarDraft.  

Enjoy!