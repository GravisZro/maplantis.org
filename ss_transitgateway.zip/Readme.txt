GRP Graphic Change
By Scourge Splitter

Transit Gateway from the Celareon Conversion
In the beta version which is currently yet going around this definate Transit Gateway structure for the 
Talon Empire isn't even featured yet.

Also this structure will be receiving an idle movement feature like the Energy Harvester will.

Contained within this zip.
- Readme file
- GRP file
- JPG image
-------------------------------------------------------------------------------------------------------