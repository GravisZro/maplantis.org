Cobra Battle Tank

Medium tank for which will be featured in the warzone2100 Mod Im currently blowing new life in.

This .zip contains:

- CobraBase.grp
- CobraTurret.grp
- Readme
- Cobra Battle Tank image

Also uasble as custom Terran tank with a more common look.
Made by: Scourge_splitter
Original creator: Peakman.