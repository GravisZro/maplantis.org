Free Market Minimod
By Laser_Dude

Version History:
1.1b:
	- Gave vulture splash, like it's supposed to be.
	- Removed L2 Goliath splash, like it's supposed to be.
1.1:
	- Fixed medic crash
	- Reduced L2 Goliath Splash
	- Vulture attack revamped.
	- Fixed a crash involving a missing requirement string.  This mainly got in because Stargraft deleted the wrong entry...
	- Tweaked balance.  L2 Marines are weaker.  Turrets are stronger.

1.0:
	- Release!

This mod is only meant to be played in Starcraft patch 1.12b.  Using any other version is likely to cause the mod to crash, have errors, or just plain not work.

Also, anything used in this mod is open source.  However, you must leave credit where it is due.

Also, this is mainly addressed to [MM]ers:  Do not try to make this mod work for a later version using FireGraft, or any other patching tool that comes up.  It contains certain sections that require specific memory offsets that FireGraft is not (or, I assume it isn't) built to upgrade.

Big thanks to the makers of the following tools which were used in the making of this modification:

Datedit
GotEd
Hex Workshop
IceCC
LO?Edit
Memgraft 1.12b
SC Downgrader 2  (I still can't get SCD3 to work!)
SCAIEdit III (for writing the blank AI I put into the mod)
SCMDraft 2
Staredit
StarForge
StarGraft
TBLPad
�becalc
Windows Calculator
WinMPQ

Whew.

Thanks to DT_Battlekruser for writing a tutorial that got me modding.

Also, thanks to Subrosian for making a kickass minable resource changing map, which I spent several hours trying to figure out. :P

Also, thanks to Heinermann/Deathknight for discovering a certain something that made this mod possible.

Biggest thanks to Blizzard, for making such an ownage game for me to mod.  I know that's not what was intended...  But I think you get it.
