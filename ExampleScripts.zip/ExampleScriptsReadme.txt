Extract these files into the same folder as RenameMaster.exe to use them.

"EG-Add(XofY)Counter.rmscr"
"EG-MoveFilesBasedOnYear.rmscr"
"EG-SwapAroundDash.rmscr"


The first script shows how to add an (X/Y) style, where X is the current file number and Y is the total number of files. Even though there is a  renaming step for adding a counter to a filename, this show how counters can be used anywhere.

The second script shows how to format a date and how to create subfolders while renaming. This script will actually create a folder using the file's Year from the date modified and move the file into that folder.

The third scrips shows how to use the file Filter, the new Remove Expression, and the ?temp? variable. In this script, all the characters before the first dash are removed and stored in the temp variable. Any leading dashes and spaces are removed. Finally, the temp variable is added to the end of the filename. This will effectively "swap" everything infront of and behind the first dash in a filename.
