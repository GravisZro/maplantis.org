AD ASTRAS
A mod for Starcraft: Brood War
by LORD_AGAMEMNON[MM] of Maplantis.org

A Clan [MM] production

-=INDEX=-

I) Miscellaneous Information
II) Version History
III) Getting Started
IV) Credits
V) Special Thanks

Hey, Roman numerals I-V make a neat curve in a monotype font.

-=I) Miscellaneous Information=-

This mod only runs on Starcraft: Brood War 1.15.0.

It should only be played on special maps--although it can be played on any, gameplay and appearance would suffer.

The three races are functionally identical.  The only differences are aesthetic ones.

-=II) Version History=-

RELEASE 1.2
Fixed bugs in the (6)A Galaxy Divided, (8)Blood Oaths, (8)Polaris, and (8)Shores of the Abyss maps that let players start with technologies in allied games.
Fixed a bug relating to planet animation level.
Reduced Inertial Bomb damage to 175.
Reduced Command Platform capacity to 6.
Fixed a readme typo.
Fixed a string error.

RELEASE 1.1
Fixed a crash related to the Command Platform.
Eleints and Command Platforms now cannot be cancelled.

RELEASE 1.0
Corrected several balance issues.
Added Entropy Circuit ability to Croniades.
Made minor requirement changes.
Fixed a bug relating to the Subspace Wormhole.
Increased maximum number of resource-yielding planets from 10 to 20.
Completed maps and map images.
Added "Getting Started" section to readme.
Differentiated the races from "Human" to "Pirate State," "Trader Guild," and "Theocracy."

BETA 2.0
Completed Sanctions.
Completed triggers.
Added wireframes.
Added icons.
Added portraits.
Corrected sounds, sight ranges, death scores, and death animations.
Corrected various minor problems.
Corrected various balance issues.
Changed Typhon-line Matriarch upgrade (Fighter transport) to Warden upgrade (Speed increase).

BETA 1.0
Basic game functions completed.


-=III) Getting Started=-

As Ad Astras is not the absolute most intuitive mod, I have provided this handy section to help those few of you
who actually read the readme.

First, unzip the files.  Presumably you've done that already, since you're reading this.

Then, read this.  It will tell you what to do.  But you knew that already.  If you just unzipped everything to
your SC directory, you can skip the next step.

Drag the "maps" folder onto your SC map directory.  It won't actually overwrite anything, just create a
sub-folder for the maps provided with the mod.

Look at the map pictures.  Aren't they pretty?  They are very pretty.  I advise easily excitable people to wear
smoked glasses when looking at them, that's how pretty they are.  Anyway, those are the maps in that folder.

Play!  You might want to play around a bit in single-player (the AI won't do anything) to get the hang of the mod.

There are many ways to get money.  They are listed here for your convenience.
  -You get 1000 material per cycle as long as you have at least one Deep Space Outpost.
  -You get 500 material per cycle per colonized planet.
  -You get 100 material per cycle per Aurora Reactor (see below).
  -You get 100 material every time a merchant ship returns cargo from a Neutral Planet to a Trade Station.
  -You get 2% of the value of your kills per Salvage Ship (see below).
  -You lose 100 material per cycle per each Umbra Reactor your opponents own (see below).

And as a reference for various points, I provide the following:
  -Any units with "Reactor" in their name--and the Vanguard--do NOT require an Outpost's power field.
  -The maximum number of Umbra Reactors/Aurora Reactors that will give you resources is 10; Planets, 20.
After that, additional ones lose their effect.

Sanctions!  Sanctions!  Sanctions!  I'll list the Sanctioned units/abilities here for you:
  -(Stabilization) Stabilization lets you control Wormholes, which can warp your ships to their location.
  -(Defense Corps) Command Platforms launch Militia Fighters to intercept enemy units.
  -(Project Anathema) Umbra Reactors remove material from your opponents over time.
  -(Project Andarist) Eleint Besiegers are slow, heavy siege ships.
  -(Project Eon) Croniades are support spellcasters with various abilities.
  -(Project Necrophagia) Salvage Ships give 2% of the value of your kills per ship, max 50%.
  -(Project Nomad) Vanguards are mobile light-ship construction yards with an attack.
  -(Project Nova) Aurora Reactors give you material.  Everyone likes money, eh?
  -(Project Megiddo) Starshock Cannon is a planet-killer weapon.
  -(Relativity Research) Inertial Bombs are fast, fragile explosives that suicide into enemies.

That's all.  Go!  Play!


-=IV) Credits=-

Practically everything: Lord_Agamemnon(MM)

GRAPHIC CREDITS:
Merchant Vessel, Merchant Freighter, Backlash graphic: Blizzard Entertainment (modified)
Merchant ship "cargo": Blizzard Entertainment, Ermac
Neutral World, Class B World, Large Ship Explosion: Syphon
Tyrant, Aurora Reactor, Umbra Reactor, Salvage Ship: Ermac
Ion Cannon: nirvanajung (modified)
Tiamat: RoryFenrir
Croniades: silent
Tyrant projectile: Voyager7456[MM]
Militia Fighter: Corbo[MM] (modified)
Pirate State console: Phobos[MM]
Icon color scheme: Voyager7456[MM]

Orbital Tender, Colony Ship, Wyvern, Draconis, Typhon, Embar, System Lock field, Planet Explosion: Lord_Agamemnon[MM]
All buildings not mentioned elsewhere: Lord_Agamemnon[MM]
All unit wireframes and icons: Lord_Agamemnon[MM] (based off of graphics by their original creators)

Embar portrait, Colony Ship portrait: Jasen
Merchant Freighter portrait: Milldawg
Tiamat portrait, Tyrant portrait, Eleint portrait: Joel Steudler
Croniades portrait, Nocturne portrait: Cynon


-=V) Special Thanks, in No Particular Order=-

Maplantis.org: You guys are great.  Really.
Isaac Asimov: The Foundation series was the original inspiration for this mod.
My father: Playing SC with me.
Blizzard Entertainment: Making SC, of course.
Hercanic: Teaching me about game balance.